ABDE TRADING LAB
================

Contenido:
- index.html: aplicación completa (HTML, CSS y JavaScript en un único archivo).

Probar en tu ordenador:
1. Abre la carpeta.
2. Haz doble clic en index.html.
3. Se abrirá en el navegador. No necesita instalación ni servidor.

Publicar gratis en GitHub Pages:
1. Entra en https://github.com e inicia sesión.
2. Pulsa el botón + (arriba) > New repository.
3. Nombre recomendado: abde-trading-lab
4. Selecciona Public y crea el repositorio.
5. Pulsa Add file > Upload files.
6. Sube index.html y pulsa Commit changes.
7. Abre Settings > Pages.
8. En Build and deployment, selecciona Deploy from a branch.
9. Selecciona la rama main y la carpeta /(root), y pulsa Save.
10. Espera uno o varios minutos. La dirección será:
    https://TU-USUARIO.github.io/abde-trading-lab/

IMPORTANTE:
- Todo es simulación; no hay broker ni órdenes reales.
- Los precios son ficticios y cambian aleatoriamente.
- La información se guarda en el almacenamiento local de ese navegador.
- Si borras los datos del navegador, puedes perder el progreso.
- Este archivo no usa API ni necesita claves secretas.
